
import pandas as pd


df= pd.DataFrame(1,3)
print (df)




